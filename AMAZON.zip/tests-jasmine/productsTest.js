import {Products,Clothing} from '../data/products.js';


describe('test suite: wirks with products',()=>{
  it('generates objects',()=>{
    
    const product1 = new Products({
    id: "3ebe75dc-64d2-4137-8860-1f5a963e534b",
    image: "images/products/6-piece-white-dinner-plate-set.jpg",
    name: "6 Piece White Dinner Plate Set",
    rating: {
      stars: 4,
      count: 37
    },
    priceCents: 2067,
    keywords: [
      "plates",
      "kitchen",
      "dining"
    ]
  });
  
  expect(product1.priceCents).toEqual(2067)
  
  expect(product1.getPrice()).toEqual('20.67')
  
  expect(product1.extraInfoHTML()).toEqual('');
  })
})

describe('test suite:works with clothing products',()=>{
  it('generates clothing objects',()=>{
    
    const product2 = new Clothing({id: "83d4ca15-0f35-48f5-b7a3-1ea210004f2e",
  image: "images/products/adults-plain-cotton-tshirt-2-pack-teal.jpg",
  name: "Adults Plain Cotton T-Shirt - 2 Pack",
  rating: {
    stars: 4.5,
    count: 56
  },
  priceCents: 799,
  keywords: [
      "tshirts",
      "apparel",
      "mens"
    ],
  type: "clothing",
  sizeChartLink: "images/clothing-size-chart.png"})
  
 expect(product2.name).toEqual('Adults Plain Cotton T-Shirt - 2 Pack');
 
 expect(product2.extraInfoHTML()).toContain('images/clothing-size-chart.png')
    
  })
  
  it('display the ratings image',()=>{
    const product4 = new Products({
    id: "3ebe75dc-64d2-4137-8860-1f5a963e534b",
    image: "images/products/6-piece-white-dinner-plate-set.jpg",
    name: "6 Piece White Dinner Plate Set",
    rating: {
      stars: 4,
      count: 37
    },
    priceCents: 2067,
    keywords: [
      "plates",
      "kitchen",
      "dining"
    ]
  })
  expect(product4.getStarsURL()).toEqual('images/ratings/rating-40.png')
  })
});

