import {renderOrderSummary} from '../scripts/checkout/orderSummary.js';

import {cart} from '../data/cart-class.js';

describe('test suite: renderOrderSummary',()=>{
  
  beforeEach( ()=>{
    spyOn(localStorage, 'setItem')
    
    document.querySelector('.order-summary-test').innerHTML=`<div class="order-summary"></div>
    <div class="payment-summary"></div>`
    
     spyOn(localStorage,'getItem').and.callFake(()=>{return JSON.stringify([{
  productId:'e43638ce-6aa0-4b85-b27f-e1d07eb678c6',
  quantity:2,
  deliveryOptionId:'1'
},
{
  productId:'15b6fc6f-327a-4ec4-896f-486349e85a3d',
  quantity:1,
  deliveryOptionId:'2'
},{
  productId:'83d4ca15-0f35-48f5-b7a3-1ea210004f2e',
  quantity:1,
  deliveryOptionId:'3'
}])})
    cart.loadCartFromStorage()
    
    renderOrderSummary()
    
  })
  it('displays the orderSummary html on the page',()=>{
 
    expect(
    document.querySelectorAll('.js-cart-item-container').length
    ).toEqual(3)
    
    expect(
    document.querySelector('.js-quantity-e43638ce-6aa0-4b85-b27f-e1d07eb678c6').innerText
    ).toEqual('2')
    
    document.querySelector('.order-summary-test').innerHTML=''
  });
  
  it('removes item',()=>{
    
    const checkoutQuantity=document.querySelector('.checkout-header-middle-section')
    
    checkoutQuantity.innerText=`Checkout (${cart.cartItems.length} items)`
    
    document.querySelector(`.js-delete-link-e43638ce-6aa0-4b85-b27f-e1d07eb678c6`).click();
    
    expect(
  document.querySelectorAll('.js-cart-item-container').length
).toEqual(2)

expect(
document.querySelector(`js-cart-item-container-e43638ce-6aa0-4b85-b27f-e1d07eb678c6`)
).toEqual(null)


  });
})
