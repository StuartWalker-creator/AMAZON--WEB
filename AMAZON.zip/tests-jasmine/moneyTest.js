import {formatCurrency} from '../scripts/utils/money.js';

describe('format currency',()=>{
 it('works with whole numbers',()=>{
   expect(formatCurrency(2025)).toEqual('20.25')
 });
 it('works with zeros(0)',()=>{
   expect(formatCurrency(0)).toEqual('0.00')
 })
})